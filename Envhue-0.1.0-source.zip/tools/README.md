# Selling Envhue Pro — manual process

Nothing here is shipped in the extension (`tools/**` is in `.vscodeignore`).

## One-time setup
1. `node tools/license-tool.js keygen <secret-folder>` — keep the private key out of every repository and back it up (password manager or encrypted drive).
2. Paste the printed public key into `src/models/licensePublicKey.ts`, build, publish.
3. Create the product at your payment provider (a merchant of record that handles VAT): one-time or yearly price. Put the checkout address in `PURCHASE_URL` (`src/ui/licenseUi.ts`) so the "Get Envhue Pro" button appears.
4. Check the provider's own sign-up requirements (business status, payout country) before announcing anything.

## For each sale (manual, fine for the first customers)
```
node tools/license-tool.js sign --private <private.pem> --id <order-number> --tier pro --holder "Customer name" --exp 2027-12-31
```
Email the printed key. The customer runs **Envhue: Enter License Key**. Use a one-year `--exp` and renew; a signed key cannot be revoked before it expires (refunds: simply do not renew).

## Later: automation
When there are enough sales, a small webhook function (provider notifies it of a paid order → it signs a key → it emails it) replaces the manual step. The private key then lives in that function's secret store.
