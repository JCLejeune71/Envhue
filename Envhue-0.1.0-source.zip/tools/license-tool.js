#!/usr/bin/env node
// Seller-side tool: creates the signing key pair and signs license keys.
// Not shipped in the extension (see .vscodeignore). Keep the private key OUT of
// every repository and backup it safely: losing it means no new keys can be
// issued for the embedded public key, leaking it means anyone can issue keys.
//
//   node tools/license-tool.js keygen <folder>
//   node tools/license-tool.js sign --private <private.pem> --id <order-id>
//        --tier pro|team [--holder "Name"] [--seats 5] [--exp 2027-12-31]

'use strict';

const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const PREFIX = 'EH1';
const b64 = (buffer) => Buffer.from(buffer).toString('base64url');

function fail(message) {
  console.error(message);
  process.exit(1);
}

function options(args) {
  const result = {};

  for (let i = 0; i < args.length; i += 2) {
    if (!args[i].startsWith('--') || args[i + 1] === undefined) {
      fail(`Unexpected argument: ${args[i]}`);
    }

    result[args[i].slice(2)] = args[i + 1];
  }

  return result;
}

const [command, ...rest] = process.argv.slice(2);

if (command === 'keygen') {
  const folder = rest[0];

  if (!folder) fail('Usage: keygen <folder>');

  fs.mkdirSync(folder, { recursive: true });

  const { publicKey, privateKey } = crypto.generateKeyPairSync('ed25519');
  const publicPem = publicKey.export({ type: 'spki', format: 'pem' });
  const privateFile = path.join(folder, 'envhue-license-private.pem');
  const publicFile = path.join(folder, 'envhue-license-public.pem');

  if (fs.existsSync(privateFile)) fail(`${privateFile} already exists; not overwriting it.`);

  fs.writeFileSync(privateFile, privateKey.export({ type: 'pkcs8', format: 'pem' }), { mode: 0o600 });
  fs.writeFileSync(publicFile, publicPem);

  console.log(`Private key (SECRET): ${privateFile}`);
  console.log(`Public key: ${publicFile}\n`);
  console.log('Paste this into src/models/licensePublicKey.ts:\n');
  console.log(`export const LICENSE_PUBLIC_KEY = ${JSON.stringify(publicPem)};`);
} else if (command === 'sign') {
  const o = options(rest);

  if (!o.private || !o.id || !['pro', 'team'].includes(o.tier)) {
    fail('Usage: sign --private <private.pem> --id <order-id> --tier pro|team [--holder X] [--seats N] [--exp YYYY-MM-DD]');
  }

  if (o.exp !== undefined && !/^\d{4}-\d{2}-\d{2}$/.test(o.exp)) fail('--exp must look like 2027-12-31');

  const payload = { v: 1, id: o.id, tier: o.tier };

  if (o.holder) payload.holder = o.holder;
  if (o.seats) payload.seats = Number(o.seats);
  if (o.exp) payload.exp = o.exp;

  const body = b64(JSON.stringify(payload));
  const signature = crypto.sign(null, Buffer.from(body), crypto.createPrivateKey(fs.readFileSync(o.private)));

  console.log(`${PREFIX}.${body}.${b64(signature)}`);
} else {
  fail('Commands: keygen <folder> | sign --private <file> --id <id> --tier pro|team [...]');
}
