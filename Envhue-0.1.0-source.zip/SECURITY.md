# Security and threat model

Envhue is a safety net against **human error**: acting on production while believing you are on DEV. It is not an access-control tool.

## What it does

- Makes the environment visible: colors, window title prefix, status bar.
- Asks for confirmation before opening sensitive environments.
- Locks files in the editor and Explorer (`files.readonlyInclude`) for read-only environments, until you unlock them for a session or a chosen duration.
- Warns when a command that looks like it changes things starts in the terminal of a locked environment.

## What it does not do

- It does not stop a command in the terminal, a task, a script or another extension from modifying files. The terminal alert only warns, relies on shell integration (VS Code 1.93+) and only knows the commands in its list.
- It does not verify that an environment really is what you declared. The type is a label you set.
- It does not manage credentials. Do not store passwords, keys or tokens in environment definitions.
- It cannot protect a machine you can reach by other means. Use server-side permissions, least-privilege accounts and approvals for real protection.

## Data

- Environments are stored in your VS Code user settings. Colors, title and lock are written to the workspace `.vscode/settings.json` of registered folders.
- No telemetry, no account, no network access of its own.

## Reporting a vulnerability

Please use GitHub's private vulnerability reporting (Security tab of the repository, "Report a vulnerability"). Do not post details in a public issue.
