// Pure module (no "vscode" import) so that it can be unit-tested.

export type Tier = 'free' | 'pro' | 'team';

/** Paid features. The free core never depends on them. */
export type Feature =
  | 'unlimitedEnvironments'
  | 'temporaryUnlock'
  | 'clientGroups'
  | 'terminalAlert';

const PAID: readonly Feature[] = [
  'unlimitedEnvironments',
  'temporaryUnlock',
  'clientGroups',
  'terminalAlert'
];

const FEATURES: Record<Tier, readonly Feature[]> = {
  free: [],
  pro: PAID,
  team: PAID
};

export function tierHasFeature(tier: Tier, feature: Feature): boolean {
  return FEATURES[tier].includes(feature);
}
