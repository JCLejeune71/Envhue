import { KeyObject, createPublicKey, createPrivateKey, sign, verify } from 'crypto';

// Pure module (no "vscode" import) so that it can be unit-tested.
//
// A license key is "EH1.<payload>.<signature>": the payload is JSON in
// base64url, the signature is an Ed25519 signature of the payload made with a
// private key that only the seller holds. The extension embeds the public key,
// so it can check a key offline. A key cannot be revoked before it expires:
// give keys an expiry date and renew them.

export const KEY_PREFIX = 'EH1';

export interface LicensePayload {
  v: 1;
  /** Unique id of the license (an order or invoice number). */
  id: string;
  tier: 'pro' | 'team';
  holder?: string;
  seats?: number;
  /** Last valid day (YYYY-MM-DD, UTC). Absent: no expiry. */
  exp?: string;
}

export type KeyCheck =
  | { ok: true; payload: LicensePayload }
  | { ok: false; reason: string };

const b64 = (data: Buffer): string => data.toString('base64url');

export function signLicenseKey(
  payload: LicensePayload,
  privateKeyPem: string | KeyObject
): string {
  const body = b64(Buffer.from(JSON.stringify(payload), 'utf8'));
  const key = typeof privateKeyPem === 'string'
    ? createPrivateKey(privateKeyPem)
    : privateKeyPem;

  return `${KEY_PREFIX}.${body}.${b64(sign(null, Buffer.from(body), key))}`;
}

function endOfDayUtc(day: string): number {
  return Date.parse(`${day}T23:59:59.999Z`);
}

export function parseLicenseKey(
  rawKey: string,
  publicKeyPem: string,
  now: Date
): KeyCheck {
  if (!publicKeyPem.trim()) {
    return { ok: false, reason: 'This build has no license public key.' };
  }

  const parts = rawKey.trim().split('.');

  if (parts.length !== 3 || parts[0] !== KEY_PREFIX) {
    return { ok: false, reason: 'This is not an Envhue license key.' };
  }

  let valid: boolean;

  try {
    valid = verify(
      null,
      Buffer.from(parts[1]),
      createPublicKey(publicKeyPem),
      Buffer.from(parts[2], 'base64url')
    );
  } catch {
    return { ok: false, reason: 'The license key could not be verified.' };
  }

  if (!valid) {
    return { ok: false, reason: 'The license key is not valid.' };
  }

  let payload: Partial<LicensePayload>;

  try {
    payload = JSON.parse(Buffer.from(parts[1], 'base64url').toString('utf8'));
  } catch {
    return { ok: false, reason: 'The license key is damaged.' };
  }

  if (
    payload.v !== 1 ||
    typeof payload.id !== 'string' ||
    (payload.tier !== 'pro' && payload.tier !== 'team')
  ) {
    return { ok: false, reason: 'The license key is not supported by this version.' };
  }

  if (payload.exp !== undefined) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(payload.exp) || Number.isNaN(endOfDayUtc(payload.exp))) {
      return { ok: false, reason: 'The license key is damaged.' };
    }

    if (endOfDayUtc(payload.exp) < now.getTime()) {
      return { ok: false, reason: `The license expired on ${payload.exp}.` };
    }
  }

  return { ok: true, payload: payload as LicensePayload };
}
