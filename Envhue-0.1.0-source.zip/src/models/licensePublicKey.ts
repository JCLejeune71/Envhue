/**
 * Ed25519 public key (PEM) used to verify license keys. Replace it with the
 * public key printed by `node tools/license-tool.js keygen`. While it is empty
 * every key is rejected and the extension stays on the Free edition.
 * The matching PRIVATE key must never be committed or shipped.
 */
export const LICENSE_PUBLIC_KEY = '';
