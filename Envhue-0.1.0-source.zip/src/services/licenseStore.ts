import * as vscode from 'vscode';
import { LicenseService } from './licenseService';
import { log } from './log';

// The key is kept in VS Code's secret storage (encrypted by the OS keychain),
// not in settings, so it does not end up in Settings Sync or a shared file.
const SECRET_KEY = 'envhue.licenseKey';

/** Loads the stored key into the license service. Never throws. */
export async function loadStoredLicense(
  context: vscode.ExtensionContext,
  license: LicenseService
): Promise<void> {
  try {
    const stored = await context.secrets.get(SECRET_KEY);
    const problem = license.setKey(stored);

    log(`license: ${stored ? (problem ?? 'key accepted') : 'no key'}`);
  } catch (error) {
    log(`license: could not read the stored key (${error instanceof Error ? error.message : String(error)})`);
  }
}

/** Checks and stores a key. Returns an error message when it is refused. */
export async function saveLicenseKey(
  context: vscode.ExtensionContext,
  license: LicenseService,
  key: string
): Promise<string | undefined> {
  const problem = license.setKey(key);

  if (problem) {
    return problem;
  }

  await context.secrets.store(SECRET_KEY, key.trim());
  return undefined;
}

export async function removeLicenseKey(
  context: vscode.ExtensionContext,
  license: LicenseService
): Promise<void> {
  license.setKey(undefined);
  await context.secrets.delete(SECRET_KEY);
}
