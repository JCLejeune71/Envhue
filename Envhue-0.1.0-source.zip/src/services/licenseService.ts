// Pure module (no "vscode" import) so that it can be unit-tested.
import { Feature, Tier, tierHasFeature } from '../models/features';
import { LicensePayload, parseLicenseKey } from '../models/licenseKey';
import { LICENSE_PUBLIC_KEY } from '../models/licensePublicKey';

/** Number of environments included in the Free edition. */
export const FREE_ENVIRONMENT_LIMIT = 4;

export interface LicenseStatus {
  tier: Tier;
  isPro: boolean;
  isTeam: boolean;
  /** 'free': no key. 'active': valid paid key. 'invalid': a key was entered but is refused. */
  state: 'free' | 'active' | 'invalid';
  holder: string | null;
  expiresAt: string | null;
  /** Why the entered key was refused. */
  reason: string | null;
}

/**
 * Decides what the installed license allows. The limit only applies to
 * *adding* environments: existing ones are never removed or locked, and they
 * can always be opened, edited and deleted. A missing, invalid or expired key
 * simply means the Free edition.
 */
export class LicenseService {
  private payload: LicensePayload | undefined;
  private rejection: string | undefined;

  constructor(
    private readonly publicKeyPem: string = LICENSE_PUBLIC_KEY,
    private readonly now: () => Date = () => new Date()
  ) {}

  /** Sets (or clears, with undefined) the key. Returns an error message if refused. */
  setKey(key: string | undefined): string | undefined {
    this.payload = undefined;
    this.rejection = undefined;

    if (!key?.trim()) {
      return undefined;
    }

    const check = parseLicenseKey(key, this.publicKeyPem, this.now());

    if (check.ok) {
      this.payload = check.payload;
      return undefined;
    }

    this.rejection = check.reason;
    return check.reason;
  }

  getStatus(): LicenseStatus {
    // Re-evaluated on every call so that a key expires while the window is open.
    const payload = this.payload && this.stillValid(this.payload)
      ? this.payload
      : undefined;
    const tier: Tier = payload?.tier ?? 'free';

    return {
      tier,
      isPro: tier === 'pro',
      isTeam: tier === 'team',
      state: payload ? 'active' : this.rejection || this.payload ? 'invalid' : 'free',
      holder: payload?.holder ?? null,
      expiresAt: payload?.exp ?? null,
      reason: payload
        ? null
        : this.rejection ?? (this.payload ? `The license expired on ${this.payload.exp}.` : null)
    };
  }

  private stillValid(payload: LicensePayload): boolean {
    return payload.exp === undefined ||
      Date.parse(`${payload.exp}T23:59:59.999Z`) >= this.now().getTime();
  }

  hasFeature(feature: Feature): boolean {
    return tierHasFeature(this.getStatus().tier, feature);
  }

  getFreeLimit(): number {
    return FREE_ENVIRONMENT_LIMIT;
  }

  /** How many more environments can be added (Infinity when unlimited). */
  remainingSlots(currentCount: number): number {
    return this.hasFeature('unlimitedEnvironments')
      ? Infinity
      : Math.max(0, this.getFreeLimit() - currentCount);
  }

  canAddEnvironment(currentCount: number): boolean {
    return this.remainingSlots(currentCount) > 0;
  }

  /** Short text for titles: "3/4 Free" or "Pro". */
  describeUsage(currentCount: number): string {
    const status = this.getStatus();

    return status.tier === 'free'
      ? `${currentCount}/${this.getFreeLimit()} Free`
      : status.tier === 'pro' ? 'Pro' : 'Team';
  }
}
