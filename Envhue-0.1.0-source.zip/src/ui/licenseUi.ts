import * as vscode from 'vscode';
import { LicenseService } from '../services/licenseService';
import { removeLicenseKey, saveLicenseKey } from '../services/licenseStore';

/** Where to buy a license. Empty until the sales page exists: no button then. */
export const PURCHASE_URL = '';

export function describePlan(license: LicenseService, environmentCount: number): string {
  const status = license.getStatus();

  if (status.tier === 'free') {
    return status.state === 'invalid'
      ? `Free · license refused (${status.reason ?? 'invalid'})`
      : `Free · ${environmentCount}/${license.getFreeLimit()} environments`;
  }

  const name = status.tier === 'pro' ? 'Pro' : 'Team';

  return status.expiresAt ? `${name} · until ${status.expiresAt}` : `${name} · no expiry`;
}

export async function enterLicenseKey(
  context: vscode.ExtensionContext,
  license: LicenseService
): Promise<boolean> {
  const key = await vscode.window.showInputBox({
    title: 'Envhue — License key',
    prompt: 'Paste your license key (it starts with EH1.)',
    password: true,
    ignoreFocusOut: true,
    validateInput: (value) =>
      !value.trim() || value.trim().startsWith('EH1.')
        ? undefined
        : 'A license key starts with EH1.'
  });

  if (!key?.trim()) {
    return false;
  }

  const problem = await saveLicenseKey(context, license, key);

  if (problem) {
    void vscode.window.showErrorMessage(`Envhue: ${problem}`);
    return false;
  }

  void vscode.window.showInformationMessage(
    `Envhue license activated: ${describePlan(license, 0)}.`
  );
  return true;
}

export async function showLicense(
  context: vscode.ExtensionContext,
  license: LicenseService,
  environmentCount: number,
  onChange: () => void
): Promise<void> {
  const status = license.getStatus();
  const items: Array<vscode.QuickPickItem & { value: 'enter' | 'remove' | 'buy' }> = [
    { label: '$(key) Enter a license key…', value: 'enter' }
  ];

  if (status.state !== 'free') {
    items.push({ label: '$(trash) Remove the license key', value: 'remove' });
  }

  if (PURCHASE_URL && status.tier === 'free') {
    items.push({ label: '$(link-external) Get Envhue Pro', value: 'buy' });
  }

  const choice = await vscode.window.showQuickPick(items, {
    title: `Envhue — ${describePlan(license, environmentCount)}`,
    placeHolder: status.holder
      ? `Licensed to ${status.holder}`
      : 'The free core is complete; Pro adds unlimited environments and temporary unlock.',
    ignoreFocusOut: true
  });

  if (!choice) {
    return;
  }

  if (choice.value === 'enter') {
    if (await enterLicenseKey(context, license)) {
      onChange();
    }
  } else if (choice.value === 'remove') {
    await removeLicenseKey(context, license);
    void vscode.window.showInformationMessage('Envhue license removed. Back to the Free edition.');
    onChange();
  } else {
    await vscode.env.openExternal(vscode.Uri.parse(PURCHASE_URL));
  }
}
