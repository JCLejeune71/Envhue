import { strict as assert } from 'node:assert';
import { generateKeyPairSync } from 'node:crypto';
import { test } from 'node:test';
import { tierHasFeature } from '../models/features';
import { signLicenseKey } from '../models/licenseKey';
import { LICENSE_PUBLIC_KEY } from '../models/licensePublicKey';
import { FREE_ENVIRONMENT_LIMIT, LicenseService } from '../services/licenseService';

const pair = () => {
  const { publicKey, privateKey } = generateKeyPairSync('ed25519');

  return {
    publicPem: publicKey.export({ type: 'spki', format: 'pem' }).toString(),
    privatePem: privateKey.export({ type: 'pkcs8', format: 'pem' }).toString()
  };
};

const day = (iso: string) => () => new Date(`${iso}T12:00:00Z`);

test('the Free edition includes four environments (DEV, TEST, PREPROD, PROD)', () => {
  assert.equal(FREE_ENVIRONMENT_LIMIT, 4);
  assert.equal(new LicenseService().getFreeLimit(), 4);
});

test('Free: environments can be added up to the limit, not beyond', () => {
  const license = new LicenseService();

  assert.equal(license.canAddEnvironment(0), true);
  assert.equal(license.canAddEnvironment(3), true);
  assert.equal(license.canAddEnvironment(4), false);
  assert.equal(license.canAddEnvironment(7), false);
  assert.equal(license.remainingSlots(1), 3);
  assert.equal(license.remainingSlots(9), 0);
  assert.equal(license.describeUsage(3), '3/4 Free');
});

test('this build ships without a public key, so no key can unlock anything', () => {
  assert.equal(LICENSE_PUBLIC_KEY, '');

  const { privatePem } = pair();
  const key = signLicenseKey({ v: 1, id: 'A1', tier: 'pro' }, privatePem);
  const license = new LicenseService();

  assert.ok(license.setKey(key));
  assert.equal(license.getStatus().tier, 'free');
});

test('a valid Pro key lifts the limit and enables paid features', () => {
  const { publicPem, privatePem } = pair();
  const license = new LicenseService(publicPem, day('2026-11-18'));
  const key = signLicenseKey(
    { v: 1, id: 'A1', tier: 'pro', holder: 'Jane', exp: '2027-11-18' },
    privatePem
  );

  assert.equal(license.setKey(key), undefined);

  const status = license.getStatus();
  assert.equal(status.tier, 'pro');
  assert.equal(status.state, 'active');
  assert.equal(status.holder, 'Jane');
  assert.equal(status.expiresAt, '2027-11-18');
  assert.equal(license.canAddEnvironment(50), true);
  assert.equal(license.remainingSlots(50), Infinity);
  assert.equal(license.hasFeature('temporaryUnlock'), true);
  assert.equal(license.describeUsage(50), 'Pro');
});

test('tampered, foreign, malformed and expired keys are refused', () => {
  const mine = pair();
  const other = pair();
  const license = new LicenseService(mine.publicPem, day('2026-11-18'));
  const good = signLicenseKey({ v: 1, id: 'A1', tier: 'pro' }, mine.privatePem);

  // Payload swapped for another one (a Team key) with the old signature.
  const team = signLicenseKey({ v: 1, id: 'A1', tier: 'team' }, mine.privatePem);
  const forged = `${good.split('.')[0]}.${team.split('.')[1]}.${good.split('.')[2]}`;

  for (const bad of [
    forged,
    signLicenseKey({ v: 1, id: 'A1', tier: 'pro' }, other.privatePem),
    'not a key',
    'EH1.abc',
    ''
  ]) {
    license.setKey(bad);
    assert.equal(license.getStatus().tier, 'free', bad);
  }

  const expired = signLicenseKey(
    { v: 1, id: 'A1', tier: 'pro', exp: '2026-11-17' },
    mine.privatePem
  );

  assert.match(license.setKey(expired) ?? '', /expired on 2026-11-17/);
  assert.equal(license.getStatus().state, 'invalid');
  assert.equal(license.canAddEnvironment(4), false);
});

test('a key expires while the window stays open', () => {
  const { publicPem, privatePem } = pair();
  let today = '2026-11-18';
  const license = new LicenseService(publicPem, () => new Date(`${today}T12:00:00Z`));

  license.setKey(signLicenseKey({ v: 1, id: 'A1', tier: 'pro', exp: '2026-11-18' }, privatePem));
  assert.equal(license.getStatus().tier, 'pro');

  today = '2026-11-19';
  assert.equal(license.getStatus().tier, 'free');
  assert.equal(license.getStatus().state, 'invalid');
});

test('free has no paid feature, pro and team have them all', () => {
  assert.equal(tierHasFeature('free', 'unlimitedEnvironments'), false);
  assert.equal(tierHasFeature('free', 'temporaryUnlock'), false);
  assert.equal(tierHasFeature('pro', 'temporaryUnlock'), true);
  assert.equal(tierHasFeature('team', 'unlimitedEnvironments'), true);
});

test('clearing the key returns to Free', () => {
  const { publicPem, privatePem } = pair();
  const license = new LicenseService(publicPem);

  license.setKey(signLicenseKey({ v: 1, id: 'A1', tier: 'pro' }, privatePem));
  license.setKey(undefined);

  assert.equal(license.getStatus().state, 'free');
  assert.equal(license.getStatus().reason, null);
});
