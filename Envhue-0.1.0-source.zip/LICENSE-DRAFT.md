# Envhue License — DRAFT

> **Draft for discussion. This is not legal advice and it is not in force.**
> Have a lawyer review and adapt it (company or sole-trader details, applicable
> law, consumer rules, VAT, refund policy) before releasing any version under it.
> The current `LICENSE` file (MIT) keeps applying to every version already
> published under it; a published MIT version cannot be withdrawn.

## 1. Scope

This license covers Envhue version [X.Y.Z] and later ("the Software"), published
by [Your legal name / business name] ("the Author"). Versions up to and including
[0.5.x] remain under the MIT License they were released under.

## 2. Free edition

You may install and use the Software for free, for personal and commercial
purposes, within the limits of the Free edition (currently up to four registered
environments and the features available without a license key).

## 3. Paid editions (Pro, Team, Business)

Additional features and limits are unlocked with a license key bought from the
Author or an authorized reseller. A key is personal to the license holder named
at purchase (Pro) or to the organization and number of seats purchased (Team,
Business), and is valid until its expiry date. Keys may not be shared or resold.

## 4. Restrictions

You may not: (a) remove, bypass or tamper with the license check or the limits of
the Free edition; (b) generate, share or distribute license keys; (c) redistribute
the Software or a modified version of it, except as allowed by section 5;
(d) use the Software to provide a competing product.

## 5. Source code and contributions

[Decide: source-available for reading and security review only? Or private?
If contributions are accepted, require a contributor agreement that lets the
Author license them under these terms.]

## 6. No telemetry

The Software does not collect usage data. License keys are verified locally.
[Update this section if a license server or telemetry is ever introduced.]

## 7. Warranty and liability

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND. The read-only
mode and the confirmation prompts are safeguards against mistakes, not security
controls: they do not prevent changes made from a terminal, a task or another
extension. [Adapt the limitation of liability to the applicable law.]

## 8. Termination, updates, support

[Support period, update policy, what happens at expiry (the Free edition keeps
working, existing environments are never removed), refund policy.]

## 9. Governing law

[France / jurisdiction of the Author.]
